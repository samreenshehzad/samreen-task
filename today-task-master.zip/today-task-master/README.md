# Mockups May 14

Check the mockups folder and create a pixel perfect clone!
published link:https://jamila-fatima.github.io/today-task/
